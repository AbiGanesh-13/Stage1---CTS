print("hi, this is my first python program")
print("Hi python")
print('welcome to python programming')
print('   sdsadsa')
print("Hi \"python\"")
print(' "python"')
print("Messsage1\tMessage2")

print("""Your Learning Path : \
\n\t- Python Basics' \
\n\t- Python Data Engineering\n\t- AI""")

