name=input("Enter the name :")
print("The name is",name)
age=int(input("Enter the age :"))
print("The age is",age)