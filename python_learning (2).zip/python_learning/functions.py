num=10
text="Hello"
#print(len(num))
print(len(text))
print(text.upper())
#print(num.upper())
print(num.bit_length())

age=int(input("Enter age :"))
name=input("Enter name :")
print("PRINTING THE VALUE, TYPE & LENGTH OF THE VARIABLE")
print(age,type(age),age.bit_length()) 
print(name,type(name),len(name))