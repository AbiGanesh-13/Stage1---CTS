country="India#"
print(country.isalpha())

phone="+91 1234567890"
print(phone.isnumeric())