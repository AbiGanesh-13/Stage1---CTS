#DATA TYPES
a=10 #integer
b=10.5 #float
c="Hello" #string
d="123" #string
e='Hi' #string
f='A' #Str
g=True #boolean
h=None #None Type
i="" #Blank is a string with no characters,it is not same as none
j=" " #String with 1 or more space character, not same as Blank
print(type(a))