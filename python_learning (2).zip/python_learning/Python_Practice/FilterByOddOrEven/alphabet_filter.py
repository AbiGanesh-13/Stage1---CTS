input_string = input("Before Filtering:\n")
input_string = input_string.upper()

result = ""
if len(input_string) % 2 == 1:
    print(ord('R'))
    result = "".join([ch for ch in input_string if (ord(ch) - ord('A') + 1) % 2 == 1])
else:
    result = "".join([ch for ch in input_string if (ord(ch) - ord('A') + 1) % 2 == 0])

print("After Filtering:")
print(result if result else "Empty")
