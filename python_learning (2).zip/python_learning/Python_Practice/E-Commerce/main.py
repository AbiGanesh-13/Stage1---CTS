from subscriber import Subscriber

def add_subscriber(input_string):
    parts = input_string.split(':')
    return Subscriber(parts[0], parts[1], parts[2])

if __name__ == "__main__":
    input_string = input("Enter the subscriber details:")
    subscriber = add_subscriber(input_string)
    bill = subscriber.calculate_bill()
    print(f"Bill for Subscriber {subscriber.subscriber_id}: ${bill}")
