class Subscriber:
    def __init__(self, subscriber_id, categories, subscription_duration):
        self.subscriber_id = subscriber_id
        self.categories = categories
        self.subscription_duration = int(subscription_duration)
    
    def calculate_bill(self):
        
        pricing = {
            'Electronics': {1: 50, 6: 250, 12: 450},
            'Clothing': {1: 30, 6: 150, 12: 270},
            'Books': {1: 10, 6: 50, 12: 90},
            'Home_Appliances': {1: 70, 6: 350, 12: 630}
        }
        
        duration = self.subscription_duration if self.subscription_duration in [1, 6, 12] else 1
        category_list = self.categories.split(',')
        total = sum(pricing.get(cat, {}).get(duration, 0) for cat in category_list)
        return total
