from payment import Payment

def add_payment_details(payment_details):
    parts = payment_details.split(',')
    payment_id = int(parts[0])
    bill_amount = float(parts[1])
    return Payment(payment_id, bill_amount)

if __name__ == "__main__":
    payment_details = input("Enter the payment details: ")
    payment = add_payment_details(payment_details)
    
    payment_type = input("Enter the payment type (Cash/Card/UPI): ")
    
    if payment_type == "Cash":
        result = payment.calculate_total_cost()
    elif payment_type == "Card":
        card_details = input("Enter card details: ")
        card_parts = card_details.split(',')
        card_number = card_parts[0].strip()
        cvv = card_parts[1].strip()
        result = payment.calculate_total_cost(card_number, cvv)
    elif payment_type == "UPI":
        upi_id = input("Enter the UPI details: ")
        result = payment.calculate_total_cost(upi_id)
    
    print(f"Calculated Total cost: {result}")
