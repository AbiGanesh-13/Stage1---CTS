class Payment:
    def __init__(self,payment_id:int,bill_amount:float):
        self.payment_id=int(payment_id)
        self.amount=float(bill_amount)
    
    def calculate_total_cost(self, *args):
        if len(args) == 0:
            total = self.amount * 0.98
            return f"{self.payment_id}:{total}"
        elif len(args) == 2:
            card_number, cvv = args
            total = self.amount * 1.05
            return f"{self.payment_id}:{card_number}:{total}"
        elif len(args) == 1:
            upi_id = args[0]
            if self.amount <= 1000:
                charge = 10
            elif self.amount <= 10000:
                charge = 20
            else:
                charge = 30
            total = self.amount + charge
            return f"{self.payment_id}:{upi_id}:{total}"
