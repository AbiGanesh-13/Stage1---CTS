name="Arun"
print(type(name))

age=25
print(type(age))
print('Your age is',age) # int
print('Your age is '+str(age)) # int only
print(type(age))
age=str(age)+5
print(type(age))
