text="  Engineering"
print("LSTRIP :")
print(text.lstrip())

text="Engineering  "
print("RSTRIP :")
print(text.rstrip())

text="   Data Engineering  "
print("STRIP :")
print(text.strip())

text="****ABC*****"
print("STRIP with custom characters :")
print(text.strip("*"))

text=" Engineering "
print(len(text))
print(len(text.strip()))
print(len(text)-len(text.strip()))

# CASE CONVERSION
print("CASE CONVERSION")
text="python PROGRAMMING"
print(text.lower())

#Example of case conversion with email
search="Email".lower()
data="email".lower()
print(search==data)

text="968-Maria, (Data Engineer) ;;27y  "
output="name: maria | role: data engineer | age: 27"
print("name: "+text[4:9].lower()+" | role: "+text[12:28].lower()+" | age: "+text[29:31].strip())

# STRING SEARCHING
print("STRING SEARCHING")

phone="+49 (176) 123-4567"
print("****STARTSWITH, ENDSWITH, IN OPERATOR****")
print(phone.startswith("+48"))

email="abi@outlook.com"
print(email.endswith("@gmail.com"))

print("@ Found in email","@" in email)
url="https://api.product.com/v1/data"

print("API URL FOUND:", "api" in url)

print("----FIND & INDEX----")
#find() is useful when combined with other methods to add dynamics
phone="+49-176 123-4567"
phone2="49-123 444 6677"
print(phone[4:])
print(phone[phone.find("-")+1:])
print(phone2[phone2.find("-")+1:])
print("find()",phone.find("-"))