price="123,87"# Europeon format
print(price.replace(",", "."))# Indian format

phone="+91 1234567890"
print(phone.replace(" ", "-").replace("-", ""))

#phone=phone.replace(" ", "-")
#print(phone)
#print(phone.replace("-", ""))
phone="+49 (176) 123-4567"
# wants output like 00491761234567
print(phone.replace(" ", "").replace("(", "").
      replace(")", "").replace("-", "").
      replace("+", "00"))

#Join Strings
print("----JOIN STRINGS-----")
first_name="Arun"
last_name="Kumar"
print(first_name+" "+last_name)

folder="C:\\Users\\Arun\\Documents"
file="report.txt"
print(folder+"\\"+file)

# Formatted String
print("FORMATTED STRING")
name="Anu"
age=22
is_student=True
print("My name is "+name+", I am "+str(age)+" years old and it is "+str(is_student)+" that I am a student.")
print("------FORMATTED STRING WITH F-STRING------")
print(f"My name is {name}, I am {age} years old and it is {is_student} that I am a student.")
print()
print("2+3 =", 2+3)
print(f"2+3 = {2+3}")

#SPLIT STRINGS
print("----SPLIT STRINGS----")
print()
stamp="2024-06-01 12:30:45"
date_time=stamp.split(" ")
print(date_time)
csv_file="Arun,25,Bangalore"
print(csv_file.split(","))

#STRING REPETITION
print("----STRING REPETITION----")
print("-"*30)

#DATA EXTRACTION (INDEXING & SLICING)
print("----DATA EXTRACTION (INDEXING & SLICING)----")
text="Python"
print()
print("Extracting First Character :")
print(text[0])
print(text[-6])
print("Extracting Last Character :")
print(text[5])
print(text[-1])
print("Extracting Substring :")
print(text[0:3]) # Extracts characters from index 0 to 2
date="2024-06-01"
print("Year =",date[0:4]) # Extracts year
print(date[:4])
print("Month =",date[5:7]) # Extracts month   
print("Day =",date[8:10]) # Extracts day
print(date[8:]) # Extracts day to end of string
print(date[-2:]) # Extracts last 2 characters