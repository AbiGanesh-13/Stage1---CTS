print('Learning Technology is Python')
tech='Python'
print("Learing technology is",tech)

name="sam"
print('info@',name,'.com')
print('support@',name,'.com')
print('www.',name,'.com')

name='9sssss'
print(name)