count_Python = 0
count_Java = 0
count_SQL = 0
num_learners = int(input("Enter the number of learners (1-50): "))
for learner_id in range(1, num_learners + 1):
    while True:
        tech = input(f"Enter the technology for learner {learner_id} (Python, Java, or SQL): ")

        if tech.capitalize() == 'PYTHON':
            count_Python += 1
            break
        elif tech.capitalize() == 'JAVA':
            count_Java += 1
            break
        elif tech.capitalize() == 'SQL':
            count_SQL += 1
            break
        else:
            print("Invalid input. Please enter a valid technology (Python, Java, or SQL).")
            
total_count = count_Python + count_Java + count_SQL
print("\nTechnology Count:")
print(f"Python: {count_Python} learners ({count_Python / total_count * 100:.2f}%)")
print(f"Java: {count_Java} learners ({count_Java / total_count * 100:.2f}%)")
print(f"SQL: {count_SQL} learners ({count_SQL / total_count * 100:.2f}%)")
if count_Python > count_Java and count_Python > count_SQL:
    most_popular = "PYTHON"
elif count_Java > count_Python and count_Java > count_SQL:
    most_popular = "JAVA"
elif count_SQL > count_Python and count_SQL > count_Java:
    most_popular = "SQL"
else:
    most_popular = "None"

if most_popular != "None":
    print(f"\nMost Popular Technology: {most_popular}")
else:
    print("\nNot Applicable")