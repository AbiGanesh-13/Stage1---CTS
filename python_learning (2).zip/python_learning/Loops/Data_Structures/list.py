# CREATING LISTS
empty=[]
letters=['a','b','c','d']
numbers=[1,2,3,4,5]
print(empty)
print(type(empty))
print(letters)
print(type(letters))
print(numbers)
print(type(numbers))

mixed=[1,'a',2.5,True]
print(mixed)    
print(type(mixed))

# CREATING LISTS USING THE LIST() FUNCTION
empty=list()    
letters=list('abcde')
numbers=list((1,2,3,4,5))   
print(empty)
print(letters)
print(numbers)

#NESTED LISTS
matrix=[[1,2,3],
        [4,5,6],
        [7,8,9]]
print(matrix)

# ACCESSING ELEMENTS IN A LIST
print(letters[0])  # Output: 'a'    
print(letters[1])  # Output: 'b'

# NEGATIVE INDEXING
print(letters[-1])  # Output: 'e'

# SLICING
print(letters[1:4])  # Output: ['b', 'c', 'd']
print(letters[:3])   # Output: ['a', 'b', 'c']

# MODIFYING LISTS
letters[0] = 'z'    
print(letters)  # Output: ['z', 'b', 'c', 'd']
letters.append('e')
print(letters)  # Output: ['z', 'b', 'c', 'd', 'e']
letters.insert(1, 'y')  
print(letters)  # Output: ['z', 'y', 'b', 'c', 'd', 'e']
letters.remove('c')
print(letters)  # Output: ['z', 'y', 'b', 'd', 'e']
letters.pop() # Removes the last element
print(letters)  # Output: ['z', 'y', 'b', 'd']
#letters.clear() 
print(letters)  # Output: []

# LIST METHODS
numbers=[1,2,3,4,5] 
print(numbers.count(2))  # Output: 1
print(numbers.index(3))  # Output: 2        
numbers.sort(reverse=True)
print(numbers)  # Output: [5, 4, 3, 2, 1]
numbers.reverse()
print(numbers)  # Output: [1, 2, 3, 4,  5]

# LIST COMPREHENSIONS
squares = [x**2 for x in range(1, 6)]
print(squares)  # Output: [1, 4, 9, 16, 25]
even_squares = [x**2 for x in range(1, 11) if x % 2 == 0]
print(even_squares)  # Output: [4, 16, 36, 64, 100]

# ITERATING OVER A LIST
print("Iterating using for loop:")

for letter in letters:  
    print(letter)
for i in range(len(numbers)):
    print(numbers[i])