# CREATING DICTIONARIES
empty_dict = {}
person = {'name': 'Alice', 'age': 30, 'city': 'New York'}
print(empty_dict)
print(person)

# ACCESSING DICTIONARY VALUES
print(person['name'])  # Output: 'Alice'
print(person.get('age'))  # Output: 30
# MODIFYING DICTIONARIES
person['age'] = 31
print(person)  # Output: {'name': 'Alice', 'age': 31, 'city': 'New York'}
person['country'] = 'USA'  # Adding a new key-value pair
print(person)  # Output: {'name': 'Alice', 'age': 31, 'city': 'New York', 'country': 'USA'}
# DICTIONARY METHODS
print(person.keys())  # Output: dict_keys(['name', 'age', 'city', 'country'])
print(person.values())  # Output: dict_values(['Alice', 31, 'New York', 'USA'])
print(person.items())  # Output: dict_items([('name', 'Alice'), ('age', 31), ('city', 'New York'), ('country', 'USA')])
person.pop('city')  # Removes the key 'city' and its value  
print(person)  # Output: {'name': 'Alice', 'age': 31, 'country': 'USA'}
person.clear()  # Removes all key-value pairs from the dictionary
print(person)  # Output: {}

# NESTED DICTIONARIES
nested_dict = {
    'person1': {'name': 'Alice', 'age': 30},
    'person2': {'name': 'Bob', 'age': 25}
}   
print(nested_dict)  # Output: {'person1': {'name': 'Alice', 'age': 30}, 'person2': {'name': 'Bob', 'age': 25}}
print(nested_dict['person1']['name'])  # Output: 'Alice'

# DICTIONARY ITERATION
for key in nested_dict:
    print(key)  # Output: 'person1', 'person2'
for key, value in nested_dict.items():
    print(f"{key}: {value}")  # Output: 'person1: {'name': 'Alice', 'age': 30}', 'person2: {'name': 'Bob', 'age': 25}'
    