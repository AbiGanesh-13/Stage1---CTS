# CREATING TUPLE    
empty_tuple = ()
fruits = ('apple', 'banana', 'cherry')
print(empty_tuple)
print(fruits)

# TUPLE METHODS
print(fruits.count('banana'))  # Output: 1
print(fruits.index('cherry'))  # Output: 2

# TUPLE IMMUTABILITY
fruits[0] = 'orange'  # This will raise an error since tuples are immutable
fruits.append('orange')  # This will also raise an error since tuples do not have an append method
# TUPLE UNPACKING
a, b, c = fruits
print(a)  # Output: 'apple'
print(b)  # Output: 'banana'
print(c)  # Output: 'cherry'

# NESTED TUPLES
nested_tuple = (1, 2, (3, 4), 5)
print(nested_tuple)  # Output: (1, 2, (3, 4), 5)
print(nested_tuple[2])  # Output: (3, 4)    
print(nested_tuple[2][0])  # Output: 3

# TUPLE SLICING
print(fruits[1:3])  # Output: ('banana', 'cherry')
print(fruits[:2])   # Output: ('apple', 'banana')

# TUPLE Iteration
for fruit in fruits:
    print(fruit)    
    
