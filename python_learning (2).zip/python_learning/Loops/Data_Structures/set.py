# CREATING SETS
empty_set = set()   
fruits = {'apple', 'banana', 'cherry'}
print(empty_set)
print(fruits)

# SET METHODS
fruits.add('orange')
print(fruits)  # Output: {'apple', 'banana', 'cherry', 'orange'}
fruits.remove('banana')
print(fruits)  # Output: {'apple', 'cherry', 'orange'}  
fruits.discard('banana')  # No error if 'banana' is not present
print(fruits)  # Output: {'apple', 'cherry', 'orange'}
fruits.pop()  # Removes an arbitrary element
print(fruits)  # Output: Remaining elements in the set

# SET OPERATIONS
A = {1, 2, 3, 4}
B = {3, 4, 5, 6}
print(A.union(B))  # Output: {1, 2, 3, 4, 5, 6}
print(A.intersection(B))  # Output: {3, 4}
print(A.difference(B))  # Output: {1, 2}

# FROZEN SETS
frozen_fruits = frozenset(['apple', 'banana', 'cherry'])
print(frozen_fruits)
frozen_fruits.add('orange')  # This will raise an error since frozensets are immutable

    
