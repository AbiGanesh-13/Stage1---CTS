from password_validation import validate_password
from exception import PasswordLengthException,PasswordCaseException,PasswordDigitException,PasswordSpecialCharException
     
    
try:
        new_password = input("Enter the new password: ")
        result = validate_password(new_password)
        print(result)
        
except (PasswordLengthException, PasswordCaseException, PasswordDigitException, PasswordSpecialCharException) as e:
       print(f"Invalid password: {e}")