import re
from exception import PasswordLengthException,PasswordCaseException,PasswordDigitException,PasswordSpecialCharException
 
def validate_password(new_password):
    try:
         # Write your code here
         if len(new_password) < 8:
             raise PasswordLengthException("Password must be at least 8 characters long")
 
         elif not (re.search(r'[a-z]', new_password) and re.search(r'[A-Z]', new_password)):
             raise PasswordCaseException("Password must contain both uppercase and lowercase letters")
     
         elif not re.search(r'\d', new_password):
             raise PasswordDigitException("Password must contain at least one digit")
 
         elif not re.search(r'[!@#$%^&*(),.?":{}|<>]', new_password):
             raise PasswordSpecialCharException("Password must contain at least one special character")
         
         else:
             return "Password updated successfully"
 
        
     
    except Exception as e:
            
        raise e