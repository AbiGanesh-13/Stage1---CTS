
class PasswordLengthException(Exception):
        pass
    
    
class PasswordCaseException(Exception):
        pass
    
    
class PasswordDigitException(Exception):
        
        
        pass
    
    
    
class PasswordSpecialCharException(Exception):
        pass