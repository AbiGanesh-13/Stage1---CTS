# EXCEPTIONS
# Exceptions are errors that occur during the execution of a program.
#  They can be handled using try-except blocks.
# Example of handling an exception
try: 
    num1 = int(input("Enter a number: "))
    num2 = int(input("Enter another number: "))
    num3=input()
    result = num1 / num2
    num1/num3 # This will raise a TypeError since num3 is a string and cannot be used in division.
    print(f"The result of {num1} divided by {num2} is: {result}")
except ZeroDivisionError as e:
    print("Error: Division by zero is not allowed.",e)
except ValueError as e:
    print("Error: Please enter valid integers.")
# In this example, if the user tries to divide by zero,
#  a ZeroDivisionError will be caught and an error message will be displayed.
#  If the user enters a non-integer value, a ValueError will be caught and an appropriate error message will be shown.
except TypeError:
    print("Error: Invalid type encountered.")

finally:
    print("This block will always execute, regardless of whether an exception occurred or not.")    
# The finally block is optional and will always execute, regardless of whether an exception occurred or not. It is often used for cleanup actions, such as closing files or releasing resources.
