print(2+3)
print(10-4)
print(5*6)  
print(20/4)  # Division always returns a float
print(20//4) # Floor division returns an integer
print(2**3)  # Exponentiation
print(10%3)  # Modulus operator returns the remainder

#SHORTHAND OPERATORS
print()
print("----SHORTHAND OPERATORS----")
x=10
x+=5  # Equivalent to x = x + 5
print(x)
x-=3  # Equivalent to x = x - 3 
print(x)
x*=2  # Equivalent to x = x * 2     
print(x)
x/=4  # Equivalent to x = x / 4
print(x)