x=10
y=3.7
z=2+3j

# TYPE CHECKING
print(type(x))
print(type(y))      
print(type(z))

#INT 
a="20"
print()
print("TYPE CONVERSION :")
print(type(a))
a=int(a)
print(type(a))
b="3.14"
print(type(b))
b=float(b)  
print(type(b))

c=10 #real
d=20 # imaginary
print(complex(c,d)) # complex number