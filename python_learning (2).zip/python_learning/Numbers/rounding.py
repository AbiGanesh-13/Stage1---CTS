import math
print(2-10)
print(abs(2-10))  # Absolute value
print(round(3.14159, 2))  # Rounding to 2 decimal places
print(round(3.14159))  # Rounding to nearest integer

#math module
print("----MATH MODULE----")
price=354.76554444
print(math.floor(price))  # Rounds down to nearest integer
print(math.ceil(price))   # Rounds up to nearest integer
print(math.trunc(price))  # Truncates the decimal part, returns integer
print(int(price))        # Converts to integer by truncating decimal part
print(math.pi)           # Prints the value of pi
print(math.sqrt(16))      # Square root of 16
