password="  123"
print(len(password))

if len(password) < 8:
    print("Password is too short")

text="""
Python is aprogramming language.
Python is created by Guido van Rossum.
It is easy to learn and use.
"""
print(text.count("Python"))