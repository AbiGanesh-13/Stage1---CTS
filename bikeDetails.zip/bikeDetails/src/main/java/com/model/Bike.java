package com.model;

import java.util.Date;

public class Bike {
	    	private String bikeId;
	    	private String brandName;
	    	private String color;
	    	private String engineType;
	    	private Date manufacturedDate;
	    	private double price;
			public String getBikeId() {
				return bikeId;
			}
			public void setBikeId(String bikeId) {
				this.bikeId = bikeId;
			}
			public String getBrandName() {
				return brandName;
			}
			public void setBrandName(String brandName) {
				this.brandName = brandName;
			}
			public String getColor() {
				return color;
			}
			public void setColor(String color) {
				this.color = color;
			}
			public String getEngineType() {
				return engineType;
			}
			public void setEngineType(String engineType) {
				this.engineType = engineType;
			}
			public Date getManufacturedDate() {
				return manufacturedDate;
			}
			public void setManufacturedDate(Date manufacturedDate) {
				this.manufacturedDate = manufacturedDate;
			}
			public double getPrice() {
				return price;
			}
			public void setPrice(double price) {
				this.price = price;
			}
			public Bike(String bikeId, String brandName, String color, String engineType, Date manufacturedDate,
					double price) {
				super();
				this.bikeId = bikeId;
				this.brandName = brandName;
				this.color = color;
				this.engineType = engineType;
				this.manufacturedDate = manufacturedDate;
				this.price = price;
			}
	    	

}
