package com.exception;

public class InvalidBikeException extends Exception {
	public InvalidBikeException(String message) {
		super(message);
	}

}
