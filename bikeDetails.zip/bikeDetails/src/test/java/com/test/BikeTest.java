package com.test;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import com.exception.InvalidBikeException;
import com.model.Bike;
import com.util.BikeUtil;

public class BikeTest {
	private static BikeUtil buObj;
	private static DateFormat df = new SimpleDateFormat("dd/MM/yyyy");
	private static List<Bike> bikes = new ArrayList<>();

	@BeforeAll
	public static void setUp() throws Exception {

		Bike[] bike = new Bike[6];

		bike[0] = new Bike("HON123", "Honda", "Red", "Petrol", df.parse("14/10/2023"), 53000.0);
		bike[1] = new Bike("YAM456", "Yamaha", "Blue", "Electric", df.parse("30/09/2023"), 75000.0);
		bike[2] = new Bike("SUS789", "Suzuki", "Black", "Petrol", df.parse("03/10/2022"), 60000.0);
		bike[3] = new Bike("ROE101", "Royal Enfield", "Silver", "Petrol", df.parse("22/11/2023"), 150000.0);
		bike[4] = new Bike("HON202", "Honda", "Yellow", "Electric", df.parse("11/11/2023"), 125000.0);
		bike[5] = new Bike("YAM303", "Yamaha", "Green", "Petrol", df.parse("22/12/2022"), 90000.0);
		bikes = new ArrayList<>(Arrays.asList(bike));
		buObj = new BikeUtil();
		buObj.setBikeList(bikes);

	}

	@Test
	public void test11ValidateBrandNameWhenYamaha() {
		boolean flag = false;
		try {
			flag = buObj.validateBrandName("Yamaha");
		} catch (InvalidBikeException e) {
		}
		assertTrue(flag);
	}

	@Test
	public void test12ValidateBrandNameWhenHonda() {
		boolean flag = false;
		try {
			flag = buObj.validateBrandName("Honda");
		} catch (InvalidBikeException e) {
		}
		assertTrue(flag);
	}

	@Test
	public void test13ValidateBrandNameWhenSuzuki() {
		boolean flag = false;
		try {
			flag = buObj.validateBrandName("Suzuki");
		} catch (InvalidBikeException e) {
		}
		assertTrue(flag);
	}

	@Test
	public void test14ValidateBrandNameWhenRoyalEnfield() {
		boolean flag = false;
		try {
			flag = buObj.validateBrandName("Royal Enfield");
		} catch (InvalidBikeException e) {
		}
		assertTrue(flag);
	}

	@Test
	public void test15ValidateBrandNameWhenInvalid() {
		boolean flag = false;
		try {
			flag = buObj.validateBrandName("KTM");
			assertTrue(false);
		} catch (InvalidBikeException e) {
		}
		assertTrue(true);
	}

	@Test
	public void test16ViewBikeDetailsByBrandName() throws InvalidBikeException {
		boolean flag = false;
		int count = 0;
		try {
			List<Bike> result = buObj.viewBikeDetailsByBrandName("Honda");
			Iterator<Bike> itr = result.iterator();
			while (itr.hasNext()) {
				Bike bike = (Bike) itr.next();
				if (bike.getBikeId().equals("HON123"))
					count++;
				if (bike.getBikeId().equals("HON202"))
					count++;

			}
			// System.out.println(count);
			if (count == 2) {
				flag = true;
			}
		} catch (InvalidBikeException e) {
		}
		assertTrue(flag);
	}

	@Test
	public void test17TotalCountOfBikesByPriceWise() throws InvalidBikeException {
		boolean flag = false;
		try {
			Map<Double, Integer> result = buObj.totalCountOfBikesByPriceWise();
			if (result.size() == 6)
				// assertTrue(true);
				flag = true;
		} catch (InvalidBikeException e) {
		}
		assertTrue(flag);
	}

	@Test
	public void test18ViewBikeDetailsByBrandNameForEmptyList() {
		boolean flag = false;
		List<Bike> bikeList = new ArrayList<>();
		BikeUtil bike4 = new BikeUtil();
		bike4.setBikeList(bikeList);
		try {
			List<Bike> appList1 = bike4.viewBikeDetailsByBrandName("TVS");
		} catch (InvalidBikeException e) {
			flag = true;
		}
		assertTrue(flag);
	}

	@Test
	       public void test19TotalCountOfBikesByPriceWiseForEmptyList() {
	       	boolean flag = false;		
	   		List<Bike> bikeList = new ArrayList<>();
	   		BikeUtil bike2=new BikeUtil();
	   		bike2.setBikeList(bikeList);
	   		try {
	   			Map<Double, Integer> res = bike2.totalCountOfBikesByPriceWise();
	   		} catch (InvalidBikeException e) {
	   			flag = true;
	  		}
	   		assertTrue(flag);
	      
}
}
