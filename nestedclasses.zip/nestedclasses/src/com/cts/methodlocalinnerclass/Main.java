package com.cts.methodlocalinnerclass;

public class Main {

	public static void main(String[] args) {
		TrainingAcademy academy = new TrainingAcademy();
		Double trainingFee1 = academy.trainingFee(30000.00, "Freshers");
		Double trainingFee2 = academy.trainingFee(45000.00, "Lateral");
		System.out.println("Freshers Fee :" + trainingFee1);
		System.out.println("Lateral Fee :" + trainingFee2);

	}

}
