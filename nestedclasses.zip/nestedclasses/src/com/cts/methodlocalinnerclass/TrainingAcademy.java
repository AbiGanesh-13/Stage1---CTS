package com.cts.methodlocalinnerclass;

public class TrainingAcademy {

	Double trainingFee(Double basicFee, String traineeType) {
		// Local variables used by local class must be final
		Double gstRate = 0.14;

		// Local class
		class FeeCalculator {
			Double getDiscount() {
				if (traineeType.equals("Freshers"))
					return 0.10;
				if (traineeType.equals("Lateral"))
					return 0.05;
				return 0.0;
			}

			Double applyDiscount(Double fee) {
				Double discount = fee * getDiscount();
				Double feeAfterDiscount = fee - discount;
				//gstRate = 0.20;
				Double gst = feeAfterDiscount * gstRate;// uses outer method variable
				System.out.println("gst :"+gst);
				return gst + feeAfterDiscount;
			}
		}
	
		FeeCalculator calculator = new FeeCalculator();
		return calculator.applyDiscount(basicFee);
	}

}
