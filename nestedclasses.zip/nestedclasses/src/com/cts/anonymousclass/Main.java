package com.cts.anonymousclass;

public class Main {

	public static void main(String[] args) {
		FoodService foodService = new FoodService() {
			
			@Override
			public void deliverOrder() {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void acceptOrder() {
				// TODO Auto-generated method stub
				
			}
		};

		

		//foodService.acceptOrder();
	}

}
