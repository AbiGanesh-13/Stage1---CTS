package com.cts.anonymousclass;
 interface FoodService {
	void acceptOrder();
	void deliverOrder();

}
