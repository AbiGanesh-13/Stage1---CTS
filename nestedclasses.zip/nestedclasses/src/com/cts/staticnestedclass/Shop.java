package com.cts.staticnestedclass;

public class Shop {//outer class
	static String location="chennai";
	static class Product {//nested static class
		// static nested class cannot access outer class not static data members 
		
		private String name;
		private Double price;

		public Product(String name, Double price) {
			super();
			this.name = name;
			this.price = price;
		}

		public void showDetails() {
			System.out.println("Product Name :" + name + "\n" + "Product Price :" + price
					+"Location "+location);
		}

	}

	public void shopDetails() {
		System.out.println("Welcome to DMart");
	}

}
