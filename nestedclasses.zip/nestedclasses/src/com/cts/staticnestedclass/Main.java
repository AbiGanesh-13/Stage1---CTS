package com.cts.staticnestedclass;

public class Main {

	public static void main(String[] args) {
		// creating object for outer class
		Shop shop = new Shop();
		shop.shopDetails();
		// creating object for static nested class
		Shop.Product product = new Shop.Product("Headphone", 2000.00);
		product.showDetails();

	}

}
