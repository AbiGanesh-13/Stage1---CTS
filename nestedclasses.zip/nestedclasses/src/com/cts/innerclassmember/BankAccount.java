package com.cts.innerclassmember;

public class BankAccount {
	private Double balance = 20000.00;

	class ATMCard {
		static Integer cardNum=75656565;
		// Inner class can access outer class private data members also
		public void withdraw(Double amount) {
			if (amount < balance) {
				balance -= amount;
				System.out.println("New Balance :" + balance);

			} else {
				System.out.println("Insufficient balance");
			}
		}

	}
	public void showBalance() {
		System.out.println("Balance :" + balance);
	}

}
