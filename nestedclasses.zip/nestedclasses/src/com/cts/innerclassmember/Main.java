package com.cts.innerclassmember;

public class Main {

	public static void main(String[] args) {
		BankAccount account = new BankAccount();
		BankAccount.ATMCard card = account.new ATMCard();//syntax
		account.showBalance();
		card.withdraw(1000.00);
		account.showBalance();
		System.out.println(BankAccount.ATMCard.cardNum);
	}

}
