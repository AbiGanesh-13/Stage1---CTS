class Task:
        def __init__(self,question_id,technology,topic,rank,difficulty_level):
            self.__question_id = question_id
            self.__technology = technology
            self.__topic = topic
            self.__rank = rank
            self.__difficulty_level= difficulty_level
           
        def get_question_id (self):
            return self.__question_id 
    
        def set_task_id(self, question_id ):
            self.__question_id  = question_id 
    
        def get_technology(self):
            return self.__technology
    
        def set_technologye(self, technology):
            self.__technology = technology
    
        def get_topic(self):
            return self.__topic
    
        def set_topic(self, topic):
            self.__topic = topic
    
        def get_rank(self):
            return self.__rank
    
        def set_rank(self, rank):
            self.__rank = rank
            
        def get_difficulty_level(self):
            return self.__difficulty_level
    
        def set_difficulty_level(self, difficulty_level):
            self.__difficulty_level = difficulty_level
            
        def calculate_completion_time(self):
            if self.__difficulty_level=='Easy':
                time=self.__rank*5
            elif self.__difficulty_level=='Medium':
                time=self.__rank*10
            elif self.__difficulty_level=='Difficult':
                time=self.__rank*15
            else:
                time=0
            return time
     