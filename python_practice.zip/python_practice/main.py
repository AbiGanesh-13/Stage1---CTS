import task as tk
def add_details(task_input):
        question_id,technology,topic,rank,difficulty_level=task_input.split(":")
        rank=int(rank)
        task_obj=tk.Task(question_id,technology,topic,rank,difficulty_level)
        time=task_obj.calculate_completion_time()
        return time
        
    
def main():
        
        task_input=input("Enter the task details:")
        time=add_details(task_input)
        print("Calculated Completion Time:",time)
        
        return
        
if __name__=='__main__':
       main()