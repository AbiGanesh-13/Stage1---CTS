tour_packages=[] # CREATING EMPTY LIST
def add_tour_package(source,destination,number_of_days,cost):
    tup=(source,destination,number_of_days,cost)
    tour_packages.append(tup)
    return tour_packages
def find_tour(source,days):
    tup_list=[]
    for tour in tour_packages:
        if source==tour[0] and tour[2]>=days:
            tup_list.append(tour)
    return tup_list
def main():
    no_of_tours=int(input("Enter the number of Tours:"))
    for i in range(no_of_tours):
        details=input("Enter Tour Details:")
        source,destination,number_of_days,cost=details.split(",")
        number_of_days=int(number_of_days)
        cost=int(cost)
        add_tour_package(source,destination,number_of_days,cost)
    source_search=input("Enter your source:")
    min_days=int(input("Enter minimum number of days:"))
    tups=find_tour(source_search,min_days)
    if tups:
        print("Trips:")
        for tup in tups:
            print("%s to %s for %d days for %d dollars"%(tup[0],tup[1],tup[2],tup[3]))
    else:
        print("No tour package found")
    return
if __name__=='__main__':
    main()
        