def main():
    i=1
    max=10
    if(i<max):
        print(i)
        i=i+1

main()        