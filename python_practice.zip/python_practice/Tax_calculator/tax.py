import exception as ex
    
class TaxCalculator:
        def __init__(self, income):
            self.__income = income
            self.__tax = 0.0
        
        def set_income(self, income):
            self.__income = income
    
        def get_income(self):
            return self.__income
        
        def set_tax(self, tax):
            self.__tax = tax
    
        def get_tax(self):
          return self.__tax
        def calculate_tax(self):
          
            if self.__income <= 10000:
                self.__tax = self.__income * 0.01
            elif self.__income <= 50000:
                self.__tax = self.__income * 0.02
            elif self.__income > 50000:
                self.__tax = self.__income * 0.03
                
            return self.__tax