class InvalidEmployeeIDException(Exception):
        message=" "
        def __init__(self,message):
            self.message=message
            
class InvalidIncomeException(Exception):
        message=" "
        def __init__(self,message):
           self.message=message