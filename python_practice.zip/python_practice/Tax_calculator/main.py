import tax as t
import exception as ex
    
def validate_employee_id(employee_id):
        try:
            
            if employee_id[:3]!="EMP":
                raise ex.InvalidEmployeeIDException("Invalid Employee ID")
            if not employee_id[3:].isdigit():
                raise ex.InvalidEmployeeIDException("Invalid Employee ID")
            
            return True 
        except ex.InvalidEmployeeIDException as e:
          
            
            return e.message
    
    
def main():
        
    try:
            emp_id = input("Enter the employee ID:")
            validate_employee_id(emp_id)
            income = int(input("Enter the income:"))
        
            if income <=0:
                raise ex.InvalidIncomeException("Invalid income. Please enter a positive non-zero income")
            else:
                emp = t.TaxCalculator(income)
                tax_amount = emp.calculate_tax()
                print(f"Tax amount: Rs.{tax_amount}")
            
    except ex.InvalidIncomeException as e:
            
            return e.message 
        
    except ValueError:
            pass
    
if __name__=='__main__':
       main()